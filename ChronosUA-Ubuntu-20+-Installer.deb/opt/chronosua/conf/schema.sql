-- =============================================================================
-- ChronosUA: Enterprise OPC UA Simulation & Delayed Write Server
-- Database Schema (PostgreSQL 16+)
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- -----------------------------------------------------------------------------
-- 1. USERS & ROLES (RBAC)
-- -----------------------------------------------------------------------------
CREATE TABLE roles (
    role_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role_name       VARCHAR(64) NOT NULL UNIQUE,
    opc_role_uri    VARCHAR(255) NOT NULL,
    description     TEXT,
    permissions     JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_system_role  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
    user_id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username            VARCHAR(128) NOT NULL UNIQUE,
    email               VARCHAR(255) UNIQUE,
    password_hash       VARCHAR(255),
    x509_thumbprint     VARCHAR(128) UNIQUE,
    x509_subject_dn     VARCHAR(512),
    auth_provider       VARCHAR(32) NOT NULL DEFAULT 'LOCAL'
                        CHECK (auth_provider IN ('LOCAL', 'X509', 'OIDC', 'LDAP')),
    is_enabled          BOOLEAN NOT NULL DEFAULT TRUE,
    is_locked           BOOLEAN NOT NULL DEFAULT FALSE,
    failed_login_count  INT NOT NULL DEFAULT 0,
    last_login_at       TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE user_roles (
    user_id     UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    role_id     UUID NOT NULL REFERENCES roles(role_id) ON DELETE CASCADE,
    assigned_by UUID REFERENCES users(user_id) ON DELETE SET NULL,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, role_id)
);

-- -----------------------------------------------------------------------------
-- 2. OPC UA NAMESPACES & ADDRESS SPACE NODES
-- -----------------------------------------------------------------------------
CREATE TABLE opc_namespaces (
    namespace_id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    namespace_index SMALLINT NOT NULL UNIQUE CHECK (namespace_index >= 0),
    namespace_uri   VARCHAR(512) NOT NULL UNIQUE,
    description     TEXT,
    is_builtin      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE opc_nodes (
    node_pk                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    node_id                 VARCHAR(512) NOT NULL UNIQUE, -- e.g. "ns=2;s=EnableBit"
    namespace_index         SMALLINT NOT NULL REFERENCES opc_namespaces(namespace_index),
    identifier_type         VARCHAR(16) NOT NULL
                            CHECK (identifier_type IN ('NUMERIC', 'STRING', 'GUID', 'OPAQUE')),
    identifier_value        VARCHAR(512) NOT NULL,
    parent_node_id          VARCHAR(512) REFERENCES opc_nodes(node_id) ON DELETE SET NULL,
    folder_path             VARCHAR(1024) NOT NULL DEFAULT '/', -- e.g. "/Objects/Simulation/PlantA/Valves"
    node_class              VARCHAR(32) NOT NULL
                            CHECK (node_class IN ('Object', 'Variable', 'Method', 'ObjectType',
                                                  'VariableType', 'ReferenceType', 'DataType', 'View')),
    browse_name             VARCHAR(255) NOT NULL,
    display_name            VARCHAR(255) NOT NULL,
    description             TEXT,
    category                VARCHAR(128) DEFAULT 'STANDARD',
    data_type               VARCHAR(128) NOT NULL DEFAULT 'Variant',
    value_rank              INT NOT NULL DEFAULT -1, -- -1: Scalar, >=1: Array dimensions
    array_dimensions        INT[],
    access_level            SMALLINT NOT NULL DEFAULT 3, -- CurrentRead (1) | CurrentWrite (2)
    user_access_level       SMALLINT NOT NULL DEFAULT 3,
    min_sampling_interval   DOUBLE PRECISION NOT NULL DEFAULT 100.0,
    historizing             BOOLEAN NOT NULL DEFAULT FALSE,
    current_value           JSONB,
    status_code             BIGINT NOT NULL DEFAULT 0, -- 0x00000000 (Good)
    source_timestamp        TIMESTAMPTZ,
    server_timestamp        TIMESTAMPTZ,
    simulation_config       JSONB, -- Waveform generator settings (Sine, Ramp, Static, etc.)
    role_permissions        JSONB, -- Per-node RBAC overrides
    is_active               BOOLEAN NOT NULL DEFAULT TRUE,
    version                 BIGINT NOT NULL DEFAULT 1,
    created_by              UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- 3. DELAY PROFILES & DELAY RULES
-- -----------------------------------------------------------------------------
CREATE TABLE delay_profiles (
    profile_id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_name            VARCHAR(128) NOT NULL UNIQUE,
    description             TEXT,
    is_enabled              BOOLEAN NOT NULL DEFAULT TRUE,
    is_active_default       BOOLEAN NOT NULL DEFAULT FALSE,
    default_write_delay_ms  BIGINT NOT NULL DEFAULT 0 CHECK (default_write_delay_ms >= 0),
    default_resp_delay_ms   BIGINT NOT NULL DEFAULT 0 CHECK (default_resp_delay_ms >= 0),
    jitter_ms               BIGINT NOT NULL DEFAULT 0 CHECK (jitter_ms >= 0),
    conflict_policy         VARCHAR(40) NOT NULL DEFAULT 'FIFO_QUEUE'
                            CHECK (conflict_policy IN (
                                'FIFO_QUEUE',
                                'LAST_WRITE_WINS_RESCHEDULE',
                                'LAST_WRITE_WINS_KEEP_SCHEDULE',
                                'REJECT_IF_PENDING'
                            )),
    timestamp_policy        VARCHAR(40) NOT NULL DEFAULT 'APPLY_AT_EXECUTION'
                            CHECK (timestamp_policy IN (
                                'APPLY_AT_EXECUTION',
                                'PRESERVE_CLIENT_SOURCE_TIMESTAMP'
                            )),
    ack_status_code_mode    VARCHAR(40) NOT NULL DEFAULT 'GOOD'
                            CHECK (ack_status_code_mode IN ('GOOD', 'GOOD_COMPLETES_ASYNCHRONOUSLY')),
    max_retries             SMALLINT NOT NULL DEFAULT 3 CHECK (max_retries BETWEEN 0 AND 20),
    retry_Backoff_base_ms   BIGINT NOT NULL DEFAULT 1000 CHECK (retry_backoff_base_ms >= 50),
    retry_backoff_max_ms    BIGINT NOT NULL DEFAULT 30000 CHECK (retry_backoff_max_ms >= 100),
    misfire_policy          VARCHAR(40) NOT NULL DEFAULT 'FIRE_IMMEDIATELY'
                            CHECK (misfire_policy IN (
                                'FIRE_IMMEDIATELY',
                                'RESCHEDULE_FROM_RECOVERY',
                                'EXPIRE_AND_AUDIT'
                            )),
    created_by              UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE delay_rules (
    rule_id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_name               VARCHAR(128) NOT NULL UNIQUE,
    profile_id              UUID NOT NULL REFERENCES delay_profiles(profile_id) ON DELETE CASCADE,
    scope_type              VARCHAR(32) NOT NULL
                            CHECK (scope_type IN ('NODE', 'PATTERN', 'FOLDER', 'CATEGORY', 'GLOBAL')),
    target_node_id          VARCHAR(512) REFERENCES opc_nodes(node_id) ON DELETE CASCADE,
    target_pattern          VARCHAR(512), -- Glob or Regex, e.g. "ns=2;s=*Valve*"
    target_folder_path      VARCHAR(1024), -- Prefix match, e.g. "/Objects/Simulation/PlantA"
    target_category         VARCHAR(128),
    is_enabled              BOOLEAN NOT NULL DEFAULT TRUE,
    write_delay_value       BIGINT NOT NULL CHECK (write_delay_value >= 0),
    write_delay_unit        VARCHAR(16) NOT NULL DEFAULT 'SECONDS'
                            CHECK (write_delay_unit IN ('MILLISECONDS', 'SECONDS', 'MINUTES')),
    write_delay_ms          BIGINT GENERATED ALWAYS AS (
                                CASE write_delay_unit
                                    WHEN 'MILLISECONDS' THEN write_delay_value
                                    WHEN 'SECONDS'      THEN write_delay_value * 1000
                                    WHEN 'MINUTES'      THEN write_delay_value * 60000
                                END
                            ) STORED,
    response_delay_ms       BIGINT NOT NULL DEFAULT 0 CHECK (response_delay_ms >= 0),
    jitter_ms               BIGINT NOT NULL DEFAULT 0 CHECK (jitter_ms >= 0),
    priority                INT NOT NULL DEFAULT 100 CHECK (priority BETWEEN 1 AND 10000),
    conflict_policy_override VARCHAR(40)
                            CHECK (conflict_policy_override IN (
                                'FIFO_QUEUE',
                                'LAST_WRITE_WINS_RESCHEDULE',
                                'LAST_WRITE_WINS_KEEP_SCHEDULE',
                                'REJECT_IF_PENDING'
                            )),
    max_retries_override    SMALLINT CHECK (max_retries_override BETWEEN 0 AND 20),
    version                 BIGINT NOT NULL DEFAULT 1,
    created_by              UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- 4. WRITE REQUESTS (ACTIVE / PENDING QUEUE & WAL)
-- -----------------------------------------------------------------------------
CREATE TABLE write_requests (
    write_id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    batch_id                UUID,
    node_id                 VARCHAR(512) NOT NULL REFERENCES opc_nodes(node_id) ON DELETE CASCADE,
    session_id              VARCHAR(128) NOT NULL,
    client_application_uri  VARCHAR(512),
    client_ip               VARCHAR(64),
    user_identity           VARCHAR(128) NOT NULL,
    attribute_id            INT NOT NULL DEFAULT 13, -- 13 = Value Attribute
    index_range             VARCHAR(64),
    previous_value          JSONB,
    requested_value         JSONB NOT NULL,
    data_type               VARCHAR(128) NOT NULL,
    client_source_timestamp TIMESTAMPTZ,
    applied_rule_id         UUID REFERENCES delay_rules(rule_id) ON DELETE SET NULL,
    applied_profile_id      UUID REFERENCES delay_profiles(profile_id) ON DELETE SET NULL,
    configured_delay_ms     BIGINT NOT NULL DEFAULT 0,
    effective_delay_ms      BIGINT NOT NULL DEFAULT 0,
    priority                INT NOT NULL DEFAULT 100,
    received_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    acknowledged_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    scheduled_at            TIMESTAMPTZ NOT NULL,
    next_retry_at           TIMESTAMPTZ,
    executed_at             TIMESTAMPTZ,
    status                  VARCHAR(32) NOT NULL DEFAULT 'PENDING'
                            CHECK (status IN (
                                'PENDING',
                                'EXECUTING',
                                'COMPLETED',
                                'COALESCED',
                                'CANCELLED',
                                'RETRYING',
                                'FAILED',
                                'DEAD_LETTER'
                            )),
    retry_count             SMALLINT NOT NULL DEFAULT 0,
    max_retries             SMALLINT NOT NULL DEFAULT 3,
    last_error_code         VARCHAR(64),
    last_error_message      TEXT,
    trace_id                VARCHAR(64),
    version                 BIGINT NOT NULL DEFAULT 1
);

-- -----------------------------------------------------------------------------
-- 5. WRITE EXECUTION HISTORY (PARTITIONED BY EXECUTED_AT)
-- -----------------------------------------------------------------------------
CREATE TABLE write_execution_history (
    history_id              UUID NOT NULL DEFAULT uuid_generate_v4(),
    write_id                UUID NOT NULL,
    batch_id                UUID,
    node_id                 VARCHAR(512) NOT NULL,
    session_id              VARCHAR(128) NOT NULL,
    user_identity           VARCHAR(128) NOT NULL,
    previous_value          JSONB,
    applied_value           JSONB NOT NULL,
    data_type               VARCHAR(128) NOT NULL,
    applied_rule_id         UUID,
    configured_delay_ms     BIGINT NOT NULL,
    received_at             TIMESTAMPTZ NOT NULL,
    scheduled_at            TIMESTAMPTZ NOT NULL,
    executed_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actual_delay_ms         BIGINT NOT NULL,
    delay_drift_ms          BIGINT NOT NULL, -- (actual_delay_ms - configured_delay_ms)
    final_status            VARCHAR(32) NOT NULL
                            CHECK (final_status IN ('COMPLETED', 'COALESCED', 'CANCELLED', 'FAILED', 'DEAD_LETTER')),
    opc_status_code         BIGINT NOT NULL DEFAULT 0,
    retry_count             SMALLINT NOT NULL DEFAULT 0,
    error_details           TEXT,
    server_instance_id      VARCHAR(128) NOT NULL,
    trace_id                VARCHAR(64),
    PRIMARY KEY (history_id, executed_at)
) PARTITION BY RANGE (executed_at);

CREATE TABLE write_execution_history_default PARTITION OF write_execution_history DEFAULT;

-- -----------------------------------------------------------------------------
-- 6. AUDIT LOGS (IMMUTABLE HASH-CHAINED, PARTITIONED BY CREATED_AT)
-- -----------------------------------------------------------------------------
CREATE TABLE audit_logs (
    audit_id                UUID NOT NULL DEFAULT uuid_generate_v4(),
    event_category          VARCHAR(32) NOT NULL
                            CHECK (event_category IN (
                                'USER_ACTION',
                                'OPC_WRITE',
                                'DELAY_LIFECYCLE',
                                'METHOD_CALL',
                                'SECURITY_EVENT',
                                'CONFIG_CHANGE',
                                'NODE_MANAGEMENT'
                            )),
    event_type              VARCHAR(64) NOT NULL,
    severity                VARCHAR(16) NOT NULL DEFAULT 'INFO'
                            CHECK (severity IN ('DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL')),
    actor_user_id           UUID,
    actor_username          VARCHAR(128) NOT NULL,
    session_id              VARCHAR(128),
    source_ip               VARCHAR(64),
    target_node_id          VARCHAR(512),
    target_resource_id      VARCHAR(255),
    action_summary          TEXT NOT NULL,
    before_state            JSONB,
    after_state             JSONB,
    metadata                JSONB,
    prev_record_hash        CHAR(64),
    record_hash             CHAR(64) NOT NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (audit_id, created_at)
) PARTITION BY RANGE (created_at);

CREATE TABLE audit_logs_default PARTITION OF audit_logs DEFAULT;

-- -----------------------------------------------------------------------------
-- 7. SERVER CONFIGURATIONS
-- -----------------------------------------------------------------------------
CREATE TABLE server_configurations (
    config_key              VARCHAR(128) PRIMARY KEY,
    config_category         VARCHAR(64) NOT NULL,
    config_value            JSONB NOT NULL,
    description             TEXT,
    is_dynamic              BOOLEAN NOT NULL DEFAULT TRUE,
    version                 BIGINT NOT NULL DEFAULT 1,
    updated_by              UUID REFERENCES users(user_id) ON DELETE SET NULL,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- INDEX STRATEGY
-- =============================================================================

-- OPC Nodes Indexes
CREATE INDEX idx_opc_nodes_parent ON opc_nodes(parent_node_id);
CREATE INDEX idx_opc_nodes_folder_path ON opc_nodes USING btree (folder_path varchar_pattern_ops);
CREATE INDEX idx_opc_nodes_category ON opc_nodes(category) WHERE is_active = TRUE;
CREATE INDEX idx_opc_nodes_trgm_search ON opc_nodes USING gin (node_id gin_trgm_ops, display_name gin_trgm_ops);

-- Delay Rules Indexes
CREATE INDEX idx_delay_rules_lookup ON delay_rules(profile_id, scope_type, priority DESC) WHERE is_enabled = TRUE;
CREATE INDEX idx_delay_rules_node ON delay_rules(target_node_id) WHERE is_enabled = TRUE AND scope_type = 'NODE';
CREATE INDEX idx_delay_rules_folder ON delay_rules USING btree (target_folder_path varchar_pattern_ops)
    WHERE is_enabled = TRUE AND scope_type = 'FOLDER';

-- Write Requests Hot Queue Partial Indexes
CREATE INDEX idx_write_requests_hot_schedule ON write_requests(scheduled_at ASC, priority DESC)
    WHERE status IN ('PENDING', 'RETRYING');
CREATE INDEX idx_write_requests_node_pending ON write_requests(node_id, received_at ASC)
    WHERE status IN ('PENDING', 'EXECUTING', 'RETRYING');
CREATE INDEX idx_write_requests_status_received ON write_requests(status, received_at DESC);

-- Write Execution History Indexes (Time-Series & Analytics)
CREATE INDEX idx_write_history_executed_brin ON write_execution_history USING brin (executed_at);
CREATE INDEX idx_write_history_node_time ON write_execution_history(node_id, executed_at DESC);
CREATE INDEX idx_write_history_write_id ON write_execution_history(write_id);
CREATE INDEX idx_write_history_status ON write_execution_history(final_status, executed_at DESC);

-- Audit Logs Indexes
CREATE INDEX idx_audit_logs_created_brin ON audit_logs USING brin (created_at);
CREATE INDEX idx_audit_logs_category_time ON audit_logs(event_category, created_at DESC);
CREATE INDEX idx_audit_logs_target_node ON audit_logs(target_node_id, created_at DESC) WHERE target_node_id IS NOT NULL;
CREATE INDEX idx_audit_logs_actor ON audit_logs(actor_username, created_at DESC);
